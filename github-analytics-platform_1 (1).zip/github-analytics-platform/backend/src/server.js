// =============================================
// src/server.js — Entry point
// =============================================

require('dotenv').config();

const app = require('./app');
const config = require('./config/env');
const { connectDatabase } = require('./config/database');
const initDb = require('./config/initDb');
const logger = require('./utils/logger');

const startServer = async () => {
  // Always start the HTTP server, even if DB is unavailable
  const server = app.listen(config.port, () => {
    logger.info(`🚀 Server running on port ${config.port} [${config.nodeEnv}]`);
    logger.info(`❤️  Health: http://localhost:${config.port}/health`);
    logger.info(`📡 API:    http://localhost:${config.port}/api`);
  });

  // Try connecting to DB separately (non-blocking)
  try {
    await connectDatabase();
    await initDb();
  } catch (error) {
    logger.warn('⚠️  Running WITHOUT database. Set DATABASE_URL in .env to enable full functionality.');
  }

  const shutdown = (signal) => {
    logger.warn(`${signal} — shutting down...`);
    server.close(() => process.exit(0));
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('unhandledRejection', (err) => logger.error('Unhandled rejection:', err));
};

startServer();
