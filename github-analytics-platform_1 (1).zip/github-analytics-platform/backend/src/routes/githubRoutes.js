// =============================================
// src/routes/githubRoutes.js
// URL definitions for GitHub analytics endpoints
// =============================================

const express = require('express');
const router = express.Router();
const githubController = require('../controllers/githubController');
const { protect } = require('../middleware/auth');
const { githubLimiter } = require('../middleware/rateLimiter');

// All GitHub routes require authentication
router.use(protect);

// Apply GitHub-specific rate limiting
router.use(githubLimiter);

// GET /api/github/analyze/:username — analyze a GitHub user
router.get('/analyze/:username', githubController.analyzeProfile);

// GET /api/github/profiles — list all saved profiles
router.get('/profiles', githubController.getAllProfiles);

// GET /api/github/profile/:id — get one profile by DB id
router.get('/profile/:id', githubController.getProfile);

module.exports = router;
