// =============================================
// src/routes/authRoutes.js
// URL definitions for authentication endpoints
// =============================================

const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { validateRegister, validateLogin } = require('../validators/authValidator');
const { protect } = require('../middleware/auth');
const { authLimiter } = require('../middleware/rateLimiter');

// Apply strict rate limiting to all auth routes
router.use(authLimiter);

// POST /api/auth/register — create a new account
router.post('/register', validateRegister, authController.register);

// POST /api/auth/login — login and get JWT token
router.post('/login', validateLogin, authController.login);

// GET /api/auth/me — get current user (protected)
router.get('/me', protect, authController.getMe);

module.exports = router;
