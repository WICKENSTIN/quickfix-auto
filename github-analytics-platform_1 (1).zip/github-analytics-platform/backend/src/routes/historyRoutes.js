// =============================================
// src/routes/historyRoutes.js
// URL definitions for search history endpoints
// =============================================

const express = require('express');
const router = express.Router();
const historyController = require('../controllers/historyController');
const { protect } = require('../middleware/auth');

// All history routes require authentication
router.use(protect);

// GET /api/history — get paginated search history
router.get('/', historyController.getHistory);

// DELETE /api/history — clear all history
router.delete('/', historyController.clearAllHistory);

// DELETE /api/history/:id — delete one history entry
router.delete('/:id', historyController.deleteHistory);

module.exports = router;
