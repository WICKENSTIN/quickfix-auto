// =============================================
// src/middleware/auth.js
// JWT Authentication Middleware
// =============================================

const jwt = require('jsonwebtoken');
const config = require('../config/env');
const { query } = require('../config/database');
const { errorResponse } = require('../utils/apiResponse');

const protect = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return errorResponse(res, 'Access denied. No token provided.', 401);
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, config.jwtSecret);

    const rows = await query(
      'SELECT id, email, name FROM users WHERE id = ?',
      [decoded.userId]
    );

    if (!rows.length) {
      return errorResponse(res, 'User no longer exists.', 401);
    }

    req.user = rows[0];
    next();
  } catch (error) {
    next(error);
  }
};

module.exports = { protect };
