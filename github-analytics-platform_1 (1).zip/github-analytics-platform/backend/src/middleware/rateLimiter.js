// =============================================
// src/middleware/rateLimiter.js
// Limits how many requests a single IP can make
// Prevents abuse and API hammering
// =============================================

const rateLimit = require('express-rate-limit');

// General API rate limiter — applies to all routes
const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes window
  max: 100,                   // Max 100 requests per window per IP
  standardHeaders: true,      // Return rate limit info in response headers
  legacyHeaders: false,
  message: {
    success: false,
    message: 'Too many requests from this IP. Please try again after 15 minutes.',
  },
});

// Strict limiter for auth routes — prevents brute force attacks
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10,                    // Only 10 login/register attempts per 15 min
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    message: 'Too many authentication attempts. Please try again after 15 minutes.',
  },
});

// GitHub API limiter — prevents burning through the GitHub rate limit
const githubLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minute window
  max: 20,                   // Max 20 GitHub searches per minute per IP
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    message: 'Too many GitHub search requests. Please wait a moment.',
  },
});

module.exports = { generalLimiter, authLimiter, githubLimiter };
