// =============================================
// src/config/database.js
// MySQL connection pool using mysql2
// =============================================

const mysql = require('mysql2/promise');

let pool;

const getPool = () => {
  if (!pool) {
    pool = mysql.createPool({
      uri: process.env.DATABASE_URL,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
    });
  }
  return pool;
};

const connectDatabase = async () => {
  try {
    const conn = await getPool().getConnection();
    console.log('✅ Database connected successfully');
    conn.release();
  } catch (error) {
    console.error('❌ Database connection failed:', error.message);
    console.warn('⚠️  Server will start without DB — fix DATABASE_URL in .env');
  }
};

// Helper: run a query with automatic connection handling
const query = async (sql, params = []) => {
  const [rows] = await getPool().execute(sql, params);
  return rows;
};

module.exports = { getPool, connectDatabase, query };
