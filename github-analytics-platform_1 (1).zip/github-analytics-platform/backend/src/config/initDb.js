// =============================================
// src/config/initDb.js
// Creates all MySQL tables automatically on startup
// No migration CLI needed — just run npm start
// =============================================

const { query } = require('./database');

const initDb = async () => {
  try {
    // USERS
    await query(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);

    // GITHUB PROFILES
    await query(`
      CREATE TABLE IF NOT EXISTS github_profiles (
        id INT AUTO_INCREMENT PRIMARY KEY,
        github_id INT NOT NULL UNIQUE,
        username VARCHAR(100) NOT NULL UNIQUE,
        name VARCHAR(255),
        bio TEXT,
        avatar_url VARCHAR(500),
        html_url VARCHAR(500),
        public_repos INT DEFAULT 0,
        followers INT DEFAULT 0,
        following INT DEFAULT 0,
        location VARCHAR(255),
        company VARCHAR(255),
        blog VARCHAR(500),
        twitter_username VARCHAR(100),
        github_created_at TIMESTAMP NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);

    // REPOSITORIES
    await query(`
      CREATE TABLE IF NOT EXISTS repositories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        github_repo_id INT NOT NULL UNIQUE,
        profile_id INT NOT NULL,
        name VARCHAR(255) NOT NULL,
        full_name VARCHAR(255),
        description TEXT,
        html_url VARCHAR(500),
        language VARCHAR(100),
        stargazers_count INT DEFAULT 0,
        forks_count INT DEFAULT 0,
        watchers_count INT DEFAULT 0,
        open_issues_count INT DEFAULT 0,
        is_private TINYINT(1) DEFAULT 0,
        is_fork TINYINT(1) DEFAULT 0,
        pushed_at TIMESTAMP NULL,
        github_created_at TIMESTAMP NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (profile_id) REFERENCES github_profiles(id) ON DELETE CASCADE
      )
    `);

    // ANALYTICS
    await query(`
      CREATE TABLE IF NOT EXISTS analytics (
        id INT AUTO_INCREMENT PRIMARY KEY,
        profile_id INT NOT NULL,
        user_id INT NOT NULL,
        total_repos INT DEFAULT 0,
        total_stars INT DEFAULT 0,
        total_forks INT DEFAULT 0,
        follower_following_ratio FLOAT DEFAULT 0,
        account_age_in_days INT DEFAULT 0,
        most_used_language VARCHAR(100),
        top_starred_repo VARCHAR(255),
        top_starred_repo_stars INT DEFAULT 0,
        recent_activity_score FLOAT DEFAULT 0,
        language_breakdown JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (profile_id) REFERENCES github_profiles(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `);

    // SEARCH HISTORY
    await query(`
      CREATE TABLE IF NOT EXISTS search_history (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        profile_id INT,
        query VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (profile_id) REFERENCES github_profiles(id) ON DELETE SET NULL
      )
    `);

    console.log('✅ All database tables ready');
  } catch (error) {
    console.error('❌ Database init error:', error.message);
    throw error;
  }
};

module.exports = initDb;
