// =============================================
// src/config/env.js
// Centralized environment variable access
// =============================================

require('dotenv').config();

const config = {
  // Server
  port: parseInt(process.env.PORT) || 5000,
  nodeEnv: process.env.NODE_ENV || 'development',
  isDev: process.env.NODE_ENV === 'development',

  // JWT
  jwtSecret: process.env.JWT_SECRET || 'fallback_secret_change_in_production',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',

  // GitHub API
  githubToken: process.env.GITHUB_TOKEN || '',

  // Frontend
  frontendUrl: process.env.FRONTEND_URL || 'http://localhost:5173',

  // Database
  databaseUrl: process.env.DATABASE_URL || '',
};

// Warn if critical env vars are missing
const requiredVars = ['JWT_SECRET', 'DATABASE_URL'];
requiredVars.forEach((varName) => {
  if (!process.env[varName]) {
    console.warn(`⚠️  Warning: ${varName} is not set in .env file`);
  }
});

module.exports = config;
