// =============================================
// src/app.js
// Express application setup
// Middleware, routes, and error handlers are configured here
// This is separate from server.js so we can test the app without starting a server
// =============================================

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

const config = require('./config/env');
const logger = require('./utils/logger');
const { generalLimiter } = require('./middleware/rateLimiter');
const { notFoundHandler, globalErrorHandler } = require('./middleware/errorHandler');

// Import all route files
const authRoutes = require('./routes/authRoutes');
const githubRoutes = require('./routes/githubRoutes');
const historyRoutes = require('./routes/historyRoutes');

const app = express();

// ─────────────────────────────────────────────
// SECURITY MIDDLEWARE
// ─────────────────────────────────────────────

// Helmet adds security-related HTTP headers automatically
app.use(helmet());

// CORS — Allow only our frontend to call this API
app.use(cors({
  origin: [config.frontendUrl, 'http://localhost:5173', 'http://localhost:3000'],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

// Apply general rate limiting to all routes
app.use(generalLimiter);

// ─────────────────────────────────────────────
// BODY PARSING MIDDLEWARE
// ─────────────────────────────────────────────

// Parse JSON request bodies (e.g., { "email": "...", "password": "..." })
app.use(express.json({ limit: '10mb' }));

// Parse URL-encoded form data
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ─────────────────────────────────────────────
// LOGGING MIDDLEWARE
// ─────────────────────────────────────────────

// Morgan logs every HTTP request to the console
// Use 'dev' format in development, 'combined' in production
if (config.isDev) {
  app.use(morgan('dev'));
} else {
  app.use(morgan('combined', {
    stream: { write: (message) => logger.info(message.trim()) },
  }));
}

// ─────────────────────────────────────────────
// HEALTH CHECK ROUTE
// Used by deployment platforms to verify the app is alive
// ─────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'GitHub Analytics Platform API is running.',
    environment: config.nodeEnv,
    timestamp: new Date().toISOString(),
  });
});

// ─────────────────────────────────────────────
// API ROUTES
// All routes are prefixed with /api
// ─────────────────────────────────────────────
app.use('/api/auth', authRoutes);
app.use('/api/github', githubRoutes);
app.use('/api/history', historyRoutes);

// ─────────────────────────────────────────────
// ERROR HANDLING (must be last)
// ─────────────────────────────────────────────
app.use(notFoundHandler);     // Catches requests to undefined routes
app.use(globalErrorHandler);  // Catches all other errors

module.exports = app;
