// =============================================
// src/controllers/authController.js
// =============================================

const authService = require('../services/authService');
const { successResponse } = require('../utils/apiResponse');

const register = async (req, res, next) => {
  try {
    const result = await authService.registerUser(req.body);
    return successResponse(res, result, 'Account created successfully.', 201);
  } catch (error) { next(error); }
};

const login = async (req, res, next) => {
  try {
    const result = await authService.loginUser(req.body);
    return successResponse(res, result, 'Logged in successfully.');
  } catch (error) { next(error); }
};

const getMe = async (req, res, next) => {
  try {
    return successResponse(res, { user: req.user }, 'Profile fetched.');
  } catch (error) { next(error); }
};

module.exports = { register, login, getMe };
