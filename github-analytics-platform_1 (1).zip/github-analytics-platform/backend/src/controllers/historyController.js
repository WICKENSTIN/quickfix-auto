// =============================================
// src/controllers/historyController.js
// =============================================

const { query } = require('../config/database');
const { successResponse, errorResponse, paginatedResponse } = require('../utils/apiResponse');

const getHistory = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;

    const history = await query(`
      SELECT sh.*, gp.username, gp.avatar_url, gp.name as profile_name,
             gp.public_repos, gp.followers
      FROM search_history sh
      LEFT JOIN github_profiles gp ON sh.profile_id = gp.id
      WHERE sh.user_id = ?
      ORDER BY sh.created_at DESC
      LIMIT ? OFFSET ?`,
      [userId, limit, offset]
    );

    const totalRows = await query(
      'SELECT COUNT(*) as total FROM search_history WHERE user_id = ?',
      [userId]
    );

    return paginatedResponse(res, history, { page, limit, total: totalRows[0].total });
  } catch (error) { next(error); }
};

const deleteHistory = async (req, res, next) => {
  try {
    const rows = await query(
      'SELECT id FROM search_history WHERE id = ? AND user_id = ?',
      [parseInt(req.params.id), req.user.id]
    );
    if (!rows.length) return errorResponse(res, 'History record not found.', 404);

    await query('DELETE FROM search_history WHERE id = ?', [parseInt(req.params.id)]);
    return successResponse(res, null, 'History record deleted.');
  } catch (error) { next(error); }
};

const clearAllHistory = async (req, res, next) => {
  try {
    await query('DELETE FROM search_history WHERE user_id = ?', [req.user.id]);
    return successResponse(res, null, 'All search history cleared.');
  } catch (error) { next(error); }
};

module.exports = { getHistory, deleteHistory, clearAllHistory };
