// =============================================
// src/controllers/githubController.js
// GitHub analytics — fetch, compute, save, return
// =============================================

const { query } = require('../config/database');
const githubService = require('../services/githubService');
const { successResponse, errorResponse, paginatedResponse } = require('../utils/apiResponse');

const analyzeProfile = async (req, res, next) => {
  try {
    const { username } = req.params;
    const userId = req.user.id;

    // 1. Fetch from GitHub API
    const [githubUser, githubRepos] = await Promise.all([
      githubService.fetchGithubUser(username),
      githubService.fetchGithubRepos(username),
    ]);

    // 2. Upsert GitHub profile
    const existing = await query('SELECT id FROM github_profiles WHERE github_id = ?', [githubUser.id]);

    let profileId;
    if (existing.length > 0) {
      profileId = existing[0].id;
      await query(`
        UPDATE github_profiles SET
          username=?, name=?, bio=?, avatar_url=?, html_url=?,
          public_repos=?, followers=?, following=?, location=?,
          company=?, blog=?, twitter_username=?, github_created_at=?,
          updated_at=NOW()
        WHERE id=?`,
        [
          githubUser.login, githubUser.name, githubUser.bio,
          githubUser.avatar_url, githubUser.html_url,
          githubUser.public_repos, githubUser.followers, githubUser.following,
          githubUser.location, githubUser.company, githubUser.blog,
          githubUser.twitter_username,
          githubUser.created_at ? new Date(githubUser.created_at) : null,
          profileId
        ]
      );
    } else {
      const result = await query(`
        INSERT INTO github_profiles
          (github_id, username, name, bio, avatar_url, html_url,
           public_repos, followers, following, location, company,
           blog, twitter_username, github_created_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [
          githubUser.id, githubUser.login, githubUser.name, githubUser.bio,
          githubUser.avatar_url, githubUser.html_url,
          githubUser.public_repos, githubUser.followers, githubUser.following,
          githubUser.location, githubUser.company, githubUser.blog,
          githubUser.twitter_username,
          githubUser.created_at ? new Date(githubUser.created_at) : null
        ]
      );
      profileId = result.insertId;
    }

    // 3. Upsert repositories (top 30 only for performance)
    for (const repo of githubRepos.slice(0, 30)) {
      const existingRepo = await query('SELECT id FROM repositories WHERE github_repo_id = ?', [repo.id]);
      if (existingRepo.length > 0) {
        await query(`
          UPDATE repositories SET
            name=?, full_name=?, description=?, html_url=?, language=?,
            stargazers_count=?, forks_count=?, watchers_count=?,
            open_issues_count=?, is_private=?, is_fork=?,
            pushed_at=?, updated_at=NOW()
          WHERE github_repo_id=?`,
          [
            repo.name, repo.full_name, repo.description, repo.html_url,
            repo.language, repo.stargazers_count, repo.forks_count,
            repo.watchers_count, repo.open_issues_count,
            repo.private ? 1 : 0, repo.fork ? 1 : 0,
            repo.pushed_at ? new Date(repo.pushed_at) : null,
            repo.id
          ]
        );
      } else {
        await query(`
          INSERT INTO repositories
            (github_repo_id, profile_id, name, full_name, description,
             html_url, language, stargazers_count, forks_count,
             watchers_count, open_issues_count, is_private, is_fork,
             pushed_at, github_created_at)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [
            repo.id, profileId, repo.name, repo.full_name, repo.description,
            repo.html_url, repo.language, repo.stargazers_count,
            repo.forks_count, repo.watchers_count, repo.open_issues_count,
            repo.private ? 1 : 0, repo.fork ? 1 : 0,
            repo.pushed_at ? new Date(repo.pushed_at) : null,
            repo.created_at ? new Date(repo.created_at) : null
          ]
        );
      }
    }

    // 4. Compute analytics
    const analytics = githubService.computeAnalytics(githubUser, githubRepos);

    // 5. Save analytics
    const existingAnalytics = await query(
      'SELECT id FROM analytics WHERE profile_id = ? AND user_id = ?',
      [profileId, userId]
    );

    if (existingAnalytics.length > 0) {
      await query(`
        UPDATE analytics SET
          total_repos=?, total_stars=?, total_forks=?,
          follower_following_ratio=?, account_age_in_days=?,
          most_used_language=?, top_starred_repo=?,
          top_starred_repo_stars=?, recent_activity_score=?,
          language_breakdown=?, updated_at=NOW()
        WHERE profile_id=? AND user_id=?`,
        [
          analytics.totalRepos, analytics.totalStars, analytics.totalForks,
          analytics.followerFollowingRatio, analytics.accountAgeInDays,
          analytics.mostUsedLanguage, analytics.topStarredRepo,
          analytics.topStarredRepoStars, analytics.recentActivityScore,
          JSON.stringify(analytics.languageBreakdown),
          profileId, userId
        ]
      );
    } else {
      await query(`
        INSERT INTO analytics
          (profile_id, user_id, total_repos, total_stars, total_forks,
           follower_following_ratio, account_age_in_days, most_used_language,
           top_starred_repo, top_starred_repo_stars, recent_activity_score,
           language_breakdown)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
        [
          profileId, userId,
          analytics.totalRepos, analytics.totalStars, analytics.totalForks,
          analytics.followerFollowingRatio, analytics.accountAgeInDays,
          analytics.mostUsedLanguage, analytics.topStarredRepo,
          analytics.topStarredRepoStars, analytics.recentActivityScore,
          JSON.stringify(analytics.languageBreakdown)
        ]
      );
    }

    // 6. Save search history
    await query(
      'INSERT INTO search_history (user_id, profile_id, query) VALUES (?,?,?)',
      [userId, profileId, username]
    );

    // 7. Get profile from DB to return
    const profileRows = await query('SELECT * FROM github_profiles WHERE id = ?', [profileId]);
    const topRepos = await query(
      'SELECT * FROM repositories WHERE profile_id = ? ORDER BY stargazers_count DESC LIMIT 10',
      [profileId]
    );

    return successResponse(res, {
      profile: profileRows[0],
      analytics,
      repositories: topRepos,
    }, 'GitHub profile analyzed successfully.');

  } catch (error) { next(error); }
};

const getProfile = async (req, res, next) => {
  try {
    const rows = await query('SELECT * FROM github_profiles WHERE id = ?', [parseInt(req.params.id)]);
    if (!rows.length) return errorResponse(res, 'Profile not found.', 404);

    const repos = await query(
      'SELECT * FROM repositories WHERE profile_id = ? ORDER BY stargazers_count DESC LIMIT 10',
      [rows[0].id]
    );
    const analyticsRows = await query(
      'SELECT * FROM analytics WHERE profile_id = ? ORDER BY created_at DESC LIMIT 1',
      [rows[0].id]
    );

    return successResponse(res, {
      profile: rows[0],
      repositories: repos,
      analytics: analyticsRows[0] || null,
    }, 'Profile fetched.');
  } catch (error) { next(error); }
};

const getAllProfiles = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;

    const profiles = await query(
      'SELECT * FROM github_profiles ORDER BY updated_at DESC LIMIT ? OFFSET ?',
      [limit, offset]
    );
    const totalRows = await query('SELECT COUNT(*) as total FROM github_profiles');
    const total = totalRows[0].total;

    return paginatedResponse(res, profiles, { page, limit, total });
  } catch (error) { next(error); }
};

module.exports = { analyzeProfile, getProfile, getAllProfiles };
