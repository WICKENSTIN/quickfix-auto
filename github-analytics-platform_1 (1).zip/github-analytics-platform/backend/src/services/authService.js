// =============================================
// src/services/authService.js
// Authentication business logic
// =============================================

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { query } = require('../config/database');
const config = require('../config/env');

const generateToken = (userId) => {
  return jwt.sign({ userId }, config.jwtSecret, { expiresIn: config.jwtExpiresIn });
};

const registerUser = async ({ name, email, password }) => {
  // Check if email exists
  const existing = await query('SELECT id FROM users WHERE email = ?', [email]);
  if (existing.length > 0) {
    const err = new Error('An account with this email already exists.');
    err.statusCode = 409;
    throw err;
  }

  // Hash password
  const hashedPassword = await bcrypt.hash(password, 12);

  // Insert user
  const result = await query(
    'INSERT INTO users (name, email, password) VALUES (?, ?, ?)',
    [name, email, hashedPassword]
  );

  const user = { id: result.insertId, name, email };
  const token = generateToken(user.id);
  return { user, token };
};

const loginUser = async ({ email, password }) => {
  const rows = await query('SELECT * FROM users WHERE email = ?', [email]);
  const user = rows[0];

  if (!user) {
    const err = new Error('Invalid email or password.');
    err.statusCode = 401;
    throw err;
  }

  const isValid = await bcrypt.compare(password, user.password);
  if (!isValid) {
    const err = new Error('Invalid email or password.');
    err.statusCode = 401;
    throw err;
  }

  const { password: _, ...safeUser } = user;
  const token = generateToken(user.id);
  return { user: safeUser, token };
};

module.exports = { registerUser, loginUser };
