// =============================================
// src/services/githubService.js
// All GitHub API calls live here
// Uses axios to fetch data from api.github.com
// =============================================

const axios = require('axios');
const config = require('../config/env');
const logger = require('../utils/logger');

// Create a pre-configured axios instance for GitHub API
const githubAPI = axios.create({
  baseURL: 'https://api.github.com',
  headers: {
    Accept: 'application/vnd.github.v3+json',
    // Include token if provided — increases rate limit from 60 to 5000 req/hr
    ...(config.githubToken && {
      Authorization: `Bearer ${config.githubToken}`,
    }),
  },
  timeout: 10000, // 10 second timeout
});

/**
 * Fetch a user's profile from GitHub
 */
const fetchGithubUser = async (username) => {
  try {
    const { data } = await githubAPI.get(`/users/${username}`);
    return data;
  } catch (error) {
    if (error.response?.status === 404) {
      const err = new Error(`GitHub user '${username}' not found.`);
      err.statusCode = 404;
      throw err;
    }
    if (error.response?.status === 403) {
      const err = new Error('GitHub API rate limit exceeded. Please try again later or add a GitHub token.');
      err.statusCode = 429;
      throw err;
    }
    logger.error('GitHub API error:', error.message);
    const err = new Error('Failed to fetch data from GitHub. Please try again.');
    err.statusCode = 502;
    throw err;
  }
};

/**
 * Fetch all repositories for a GitHub user (handles pagination)
 */
const fetchGithubRepos = async (username) => {
  try {
    let allRepos = [];
    let page = 1;
    const perPage = 100; // Max GitHub allows per page

    while (true) {
      const { data } = await githubAPI.get(`/users/${username}/repos`, {
        params: {
          per_page: perPage,
          page,
          sort: 'updated', // Most recently updated first
          type: 'owner',    // Only repos they own (not forks they don't own)
        },
      });

      allRepos = [...allRepos, ...data];

      // Stop if we've fetched all pages
      if (data.length < perPage) break;
      page++;

      // Safety limit — don't fetch more than 1000 repos
      if (allRepos.length >= 1000) break;
    }

    return allRepos;
  } catch (error) {
    logger.error('GitHub repos fetch error:', error.message);
    throw error;
  }
};

/**
 * Compute analytics from raw GitHub profile + repos data
 */
const computeAnalytics = (profile, repos) => {
  // Calculate total stars and forks across all repos
  const totalStars = repos.reduce((sum, repo) => sum + repo.stargazers_count, 0);
  const totalForks = repos.reduce((sum, repo) => sum + repo.forks_count, 0);

  // Follower/following ratio (avoid division by zero)
  const followerFollowingRatio = profile.following > 0
    ? parseFloat((profile.followers / profile.following).toFixed(2))
    : profile.followers;

  // Account age in days
  const createdAt = new Date(profile.created_at);
  const accountAgeInDays = Math.floor((Date.now() - createdAt.getTime()) / (1000 * 60 * 60 * 24));

  // Most used programming language
  const languageCounts = {};
  repos.forEach((repo) => {
    if (repo.language) {
      languageCounts[repo.language] = (languageCounts[repo.language] || 0) + 1;
    }
  });
  const mostUsedLanguage = Object.keys(languageCounts).sort(
    (a, b) => languageCounts[b] - languageCounts[a]
  )[0] || null;

  // Top starred repository
  const topRepo = repos.sort((a, b) => b.stargazers_count - a.stargazers_count)[0];

  // Recent activity score: count repos updated in last 90 days
  const ninetyDaysAgo = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
  const recentlyActiveRepos = repos.filter(
    (repo) => new Date(repo.pushed_at) > ninetyDaysAgo
  ).length;
  const recentActivityScore = repos.length > 0
    ? parseFloat(((recentlyActiveRepos / repos.length) * 100).toFixed(2))
    : 0;

  return {
    totalRepos: profile.public_repos,
    totalStars,
    totalForks,
    followerFollowingRatio,
    accountAgeInDays,
    mostUsedLanguage,
    topStarredRepo: topRepo?.name || null,
    topStarredRepoStars: topRepo?.stargazers_count || 0,
    recentActivityScore,
    languageBreakdown: languageCounts,
  };
};

module.exports = { fetchGithubUser, fetchGithubRepos, computeAnalytics };
