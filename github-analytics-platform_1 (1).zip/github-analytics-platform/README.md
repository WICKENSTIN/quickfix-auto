# GitHub Analytics Platform

A production-grade full-stack SaaS application that analyzes GitHub users and repositories.

## Tech Stack

**Backend:** Node.js, Express.js, Prisma ORM, MySQL, JWT  
**Frontend:** React, Vite, Tailwind CSS (Phase 2)  
**Deployment:** Vercel (frontend), Render (backend), Railway (MySQL)

---

## Quick Start

### 1. Clone & Install

```bash
git clone <your-repo-url>
cd github-analytics-platform/backend
npm install
```

### 2. Setup Environment

```bash
cp .env.example .env
# Edit .env with your Railway MySQL URL and other values
```

### 3. Setup Database

```bash
# Generate Prisma client
npm run db:generate

# Run migrations (creates all tables)
npm run db:migrate
```

### 4. Run Development Server

```bash
npm run dev
```

Server starts at: `http://localhost:5000`  
Health check: `http://localhost:5000/health`

---

## API Endpoints

### Authentication
| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | `/api/auth/register` | Create new account | No |
| POST | `/api/auth/login` | Login and get JWT | No |
| GET | `/api/auth/me` | Get current user | Yes |

### GitHub Analytics
| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/api/github/analyze/:username` | Analyze a GitHub user | Yes |
| GET | `/api/github/profiles` | List saved profiles | Yes |
| GET | `/api/github/profile/:id` | Get profile by ID | Yes |

### Search History
| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/api/history` | Get search history | Yes |
| DELETE | `/api/history/:id` | Delete one record | Yes |
| DELETE | `/api/history` | Clear all history | Yes |

---

## Authentication

Include the JWT token in every protected request:

```
Authorization: Bearer <your-jwt-token>
```

---

## Environment Variables

See `.env.example` for all required variables.

| Variable | Description |
|----------|-------------|
| `PORT` | Server port (default: 5000) |
| `DATABASE_URL` | MySQL connection string |
| `JWT_SECRET` | Secret key for signing tokens |
| `JWT_EXPIRES_IN` | Token expiry (e.g. `7d`) |
| `GITHUB_TOKEN` | GitHub Personal Access Token (optional) |
| `FRONTEND_URL` | Frontend URL for CORS |

---

## Railway MySQL Setup

1. Go to [railway.app](https://railway.app) and create an account
2. Click **New Project** → **Provision MySQL**
3. Click on the MySQL service → **Connect** tab
4. Copy the `DATABASE_URL` and paste it into your `.env` file
5. Run `npm run db:migrate` to create all tables

---

## Docker

```bash
# Run everything (backend + MySQL) with Docker
docker-compose up

# Run in background
docker-compose up -d

# Stop
docker-compose down
```

---

## Deployment

### Backend → Render
1. Push code to GitHub
2. Create new **Web Service** on [render.com](https://render.com)
3. Connect your GitHub repo
4. Set build command: `npm install && npm run db:generate`
5. Set start command: `npm start`
6. Add all environment variables from `.env`

### Database → Railway
- Already covered above

### Frontend → Vercel (Phase 2)
- Will be covered when frontend is built

---

## Folder Structure

```
backend/
├── src/
│   ├── config/          # Database & environment config
│   ├── controllers/     # Request handlers
│   ├── routes/          # URL definitions
│   ├── middleware/       # Auth, error handling, rate limiting
│   ├── services/        # Business logic
│   ├── validators/      # Input validation
│   ├── utils/           # Logger, response helpers
│   ├── prisma/          # Database schema
│   ├── app.js           # Express app
│   └── server.js        # Entry point
├── .env.example
├── Dockerfile
└── package.json
```

---

## License

MIT
